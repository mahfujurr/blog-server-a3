
// src/services/warehouse.service.ts
import { TWarehouseItem } from "./warehouseItems.interface";
import { WarehouseItemModel, WarehousePurchaseHistoryModel } from "./warehouseItems.model";
// interface WarehousePayload {
//   warehouseId: string;
//   items: TWarehouseItem[];
// }
// const createMultipleWarehouseItemsIntoDB = async (payload: WarehousePayload) => {
//   try {
//     const { items, warehouseId, ...otherData } = payload;
//     const updatedRecords = [];

//     for (const item of items) {
//       // ✅ Step 1: Save raw unprocessed data into history
//       await WarehousePurchaseHistoryModel.create({
//         ...otherData,
//         ...item,
//         warehouse: warehouseId,
//       });

//       // ✅ Step 2: Check if item already exists in current inventory
//       const existingItem = await WarehouseItemModel.findOne({
//         warehouse: warehouseId,
//         itemDescription: item.itemDescription,
//       });

//       if (existingItem) {
//         // ✅ Step 3: Update qty and average price
//         const totalQty = existingItem.qty + item.qty;
//         const avgPrice =
//           ((existingItem.purchasePrice * existingItem.qty) +
//             (item.purchasePrice * item.qty)) /
//           totalQty;

//         existingItem.qty = totalQty;
//         existingItem.purchasePrice = avgPrice;
//         await existingItem.save();
//         updatedRecords.push(existingItem);
//       } else {
//         // ✅ Step 4: Create new warehouse item
//         const newItem = await WarehouseItemModel.create({
//           ...otherData,
//           warehouse: warehouseId,
//           itemDescription: item.itemDescription,
//           origin: item.origin,
//           packing: item.packing,
//           grade: item.grade || null,
//           qty: item.qty,
//           purchasePrice: item.purchasePrice,
//         });
//         updatedRecords.push(newItem);
//       }
//     }

//     return {
//       success: true,
//       message: "Warehouse records saved/updated successfully",
//       data: updatedRecords,
//     };
//   } catch (error) {
//     return { success: false, message: "Failed to save data", error };
//   }
// };



const createWarehouseItemIntoDB = async (payload: TWarehouseItem) => {
  try {
    await WarehousePurchaseHistoryModel.create(payload);
    const { items, warehouse } = payload;
    const updatedRecords = [];
    for (const item of items) {
      // ✅ Step 1: Save raw unprocessed data into history

      // await WarehousePurchaseHistoryModel.create({
      //   ...otherData,
      //   ...item,
      //   warehouse: warehouse,
      // });

      // ✅ Step 2: Check if item already exists in current inventory
      const existingItem = await WarehouseItemModel.findOne({
        warehouse: warehouse,
        itemDescription: item.itemDescription,
      });

      if (existingItem) {
        // ✅ Step 3: Update qty and average price
        const totalQty = existingItem.qty + item.qty;
        const avgPrice =
          ((existingItem.purchasePrice * existingItem.qty) +
            (item.purchasePrice * item.qty)) /
          totalQty;

        existingItem.qty = totalQty;
        existingItem.purchasePrice = avgPrice;
        await existingItem.save();
        updatedRecords.push(existingItem);
      } else {
        // ✅ Step 4: Create new warehouse item
        const newItem = await WarehouseItemModel.create({
          warehouse: warehouse,
          itemDescription: item.itemDescription,
          origin: item.origin,
          packing: item.packing,
          grade: item.grade || null,
          qty: item.qty,
          purchasePrice: item.purchasePrice,
        });
        updatedRecords.push(newItem);
      }
    }
    return {
      success: true,
      message: "Warehouse records saved/updated successfully",
      data: updatedRecords,
    };
  } catch (error) {
    return { success: false, message: "Failed to save data", error };
  }
};

const getAllWarehouseItemsFromDB = async () => {
  return await WarehouseItemModel.find().populate("warehouse");
};

const getSingleWarehouseItemFromDB = async (id: string) => {
  return await WarehouseItemModel.findOne({ id }).populate("warehouse");
};

const updateWarehouseItemIntoDB = async (id: string, payload: Partial<TWarehouseItem>) => {
  return await WarehouseItemModel.findByIdAndUpdate(id, payload, { new: true });
};
// services/warehouseItem.service.ts



// const bulkDeductItemsByWarehouseIntoDB = async (
//   warehouseId: string,
//   items: {
//     itemDescription: string;
//     qty: number;
//     selectedWarehouse: string;
//   }[]
// ) => {
//   try {
//     const updatedRecords = [];

//     for (const item of items) {
//       const existingItem = await WarehouseItemModel.findOne({
//         selectedWarehouse: item.selectedWarehouse,
//         itemDescription: item.itemDescription,
//       });

//       if (!existingItem) {
//         throw new Error(`Item "${item.itemDescription}" not found in warehouse.`);
//       }

//       if (existingItem.qty < item.qty) {
//         throw new Error(`Not enough stock for "${item.itemDescription}". Available: ${existingItem.qty}, Requested: ${item.qty}`);
//       }

//       existingItem.qty -= item.qty;
//       await existingItem.save();
//       updatedRecords.push(existingItem);
//     }

//     return {
//       success: true,
//       message: "Warehouse items quantities deducted successfully",
//       data: updatedRecords,
//     };
//   } catch (error) {
//     return {
//       success: false,
//       message: "Failed to deduct warehouse items",

//     };
//   }
// };




const deleteWarehouseItemFromDB = async (id: string) => {
  return await WarehouseItemModel.findOneAndDelete({ id });
};
const getAllPurchaseHistoryFromDB = async () => {
  return await WarehousePurchaseHistoryModel.find().sort({ createdAt: -1 }).populate("warehouse");
};
const getSinglePurchaseHistoryFromDB = async (id: string) => {
  return await WarehousePurchaseHistoryModel.findById(id).populate("warehouse");
};

const createPurchaseHistoryIntoDB = async (payload: TWarehouseItem) => {
  return await WarehousePurchaseHistoryModel.create(payload);
};
// src/services/warehouse.service.ts

const updatePurchaseHistoryIntoDB = async (
  id: string,
  payload: Partial<TWarehouseItem>
) => {
  return await WarehousePurchaseHistoryModel.findByIdAndUpdate(id, payload, {
    new: true,
  }).populate("warehouse");
};

const deletePurchaseHistoryFromDB = async (id: string) => {
  return await WarehousePurchaseHistoryModel.findByIdAndDelete(id);
};


export const warehouseItemService = {
  createWarehouseItemIntoDB,
  getAllWarehouseItemsFromDB,
  getSingleWarehouseItemFromDB,
  updateWarehouseItemIntoDB,
  deleteWarehouseItemFromDB,
  // bulkDeductItemsByWarehouseIntoDB,
  // createMultipleWarehouseItemsIntoDB,
  // 🕓 Purchase History
  getAllPurchaseHistoryFromDB,
  getSinglePurchaseHistoryFromDB,
  createPurchaseHistoryIntoDB,
  updatePurchaseHistoryIntoDB,
  deletePurchaseHistoryFromDB
};