// src/types/warehouse.ts
export type TWarehouse = {
    name: string;
    description: string;
};