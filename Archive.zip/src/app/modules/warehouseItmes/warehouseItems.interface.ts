import mongoose from "mongoose";
type TItem = {
  itemDescription: string;
  origin: string;
  packing: string;
  grade: string;
  qty: number;
  key: number;
  purchasePrice: number;
}
export type TWarehouseItem = {
  supplierName1?: string;
  proformaInvoiceNo?: string;
  invoiceNo?: string;
  supplierContractNo1?: string;
  customerOrderNo1?: string;
  buyingTerms1?: string;
  shipmentTerm1?: string;
  shipmentDate1?: Date;
  estimatedArrivalDate1?: Date;
  blNumber1?: string;
  vesselVoyageNo?: string;
  loadingPort1?: string;
  dischargePort1?: string;
  selectedWarehouse?: string;
  notes?: string;
  shippingCompanyName?: string;
  shippingInvoiceNo?: string;
  shippingDate?: Date;
  shippingCost?: number;
  insurance?: number;
  currency?: string;
  warehouse?: mongoose.Types.ObjectId; // Reference to Warehouse
  items?: TItem[];
};
