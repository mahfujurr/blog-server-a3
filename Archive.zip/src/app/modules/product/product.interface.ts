
export type TProduct = {
    description: string;
    HSCode : string;
    units: string;
    packing: string;
    grade:string;
    origin:string;
};