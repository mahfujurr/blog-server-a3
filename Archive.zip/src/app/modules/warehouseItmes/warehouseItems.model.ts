import mongoose, { Schema } from "mongoose";
import { TWarehouseItem } from "./warehouseItems.interface";

const WarehouseItemSchema = new Schema<TWarehouseItem>(
  {
    supplierName1: { type: String, },
    proformaInvoiceNo: { type: String, },
    invoiceNo: { type: String, },
    supplierContractNo1: { type: String },
    customerOrderNo1: { type: String },
    buyingTerms1: { type: String },
    shipmentTerm1: { type: String },
    shipmentDate1: { type: Date },
    estimatedArrivalDate1: { type: Date },
    blNumber1: { type: String },
    vesselVoyageNo: { type: String },
    loadingPort1: { type: String },
    dischargePort1: { type: String },
    selectedWarehouse: { type: String },
    notes: { type: String },
    shippingCompanyName: { type: String },
    shippingInvoiceNo: { type: String },
    shippingDate: { type: Date },
    shippingCost: { type: Number },
    insurance: { type: Number },
    currency: { type: String },
    warehouse: { type: Schema.Types.ObjectId, ref: "Warehouse", required: true },

    items: [
      {
        itemDescription: { type: String, },
        origin: { type: String, },
        packing: { type: String, },
        grade: { type: String },
        qty: { type: Number, },
        key: { type: Number, },
        purchasePrice: { type: Number, },

      },
    ],
    // প্রতিটি ডকুমেন্টে একটি `item` থাকবে
    // itemDescription: { type: String },
    // origin: { type: String },
    // packing: { type: String },
    // grade: { type: String },
    // qty: { type: Number },
    // key: { type: Number },
    // purchasePrice: { type: Number },

  },
  { timestamps: true }
);

export const WarehouseItemModel = mongoose.model<TWarehouseItem>("WarehouseItem", WarehouseItemSchema);
export const WarehousePurchaseHistoryModel = mongoose.model<TWarehouseItem>(
  "WarehousePurchaseHistory", // 👈 collection name
  WarehouseItemSchema // 👈 reuse the exact same schema
);
